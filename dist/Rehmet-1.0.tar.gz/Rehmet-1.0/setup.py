from setuptools import setup, find_packages

setup(
    name = 'Rehmet',
    version='1.0',
    author='reh',
    author_email='toygame8888@gmail.com',
    packages=find_packages(),
)